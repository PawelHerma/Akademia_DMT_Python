# wypisuje liczby od 1 do 10 bez wykorzystania funkcji range()
i = 1
while i <=10:
    print(i)
    i += 1