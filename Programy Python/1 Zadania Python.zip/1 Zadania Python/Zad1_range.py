# wypisuje liczby od 1 do 10 z wykorzystaniem funkcji range
for i in range (1, 11):
    print(i)