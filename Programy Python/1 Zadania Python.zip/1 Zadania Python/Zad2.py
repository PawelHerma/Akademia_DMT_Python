# wypisuje alfabet od a do z
for i in range (97, 123):
    print(chr(i))